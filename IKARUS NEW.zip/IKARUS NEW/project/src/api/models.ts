import { Model3D } from '../types';
const models: Model3D[] = [
  {
    id: '2',
    name: 'Helmet',
    description: 'Helmet',
    url: 'https://threejs.org/examples/models/gltf/DamagedHelmet/glTF/DamagedHelmet.gltf',
    thumbnail: ''
  },
  {
    id: '4',
    name: 'Parrot',
    description: 'Parrot',
    url: 'https://threejs.org/examples/models/gltf/Parrot.glb',
    thumbnail: ''
  }
];

// Function to fetch all models
export const fetchModels = async (): Promise<Model3D[]> => {
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(models);
    }, 500);
  });
};

// Function to search models by name
export const searchModels = async (query: string): Promise<Model3D[]> => 
  {
  return new Promise((resolve) => {
    setTimeout(() => {
      const filteredModels = models.filter(model => 
        model.name.toLowerCase().includes(query.toLowerCase())
      );
      resolve(filteredModels);
    }, 300);
  });
};

// Function to get a model by ID
export const getModelById = async (id: string): Promise<Model3D | undefined> => {
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      const model = models.find(model => model.id === id);
      resolve(model);
    }, 200);
  });
};