import React, { useEffect, useState } from 'react';
import ModelViewer from './components/ModelViewer';
import ModelCard from './components/ModelCard';
import { fetchModels } from './api/models';
import { Model3D } from './types';
import { Cuboid as Cube3D, Loader2, Upload } from 'lucide-react';

function App() {
  const [models, setModels] = useState<Model3D[]>([]);
  const [selectedModel, setSelectedModel] = useState<Model3D | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadedModel, setUploadedModel] = useState<string | null>(null);

  // Fetch models on component mount
  useEffect(() => {
    const getModels = async () => {
      setIsLoading(true);
      try {
        const data = await fetchModels();
        setModels(data);
        if (data.length > 0) {
          setSelectedModel(data[0]);
        }
      } catch (error) {
        console.error('Error fetching models:', error);
      } finally {
        setIsLoading(false);
      }
    };

    getModels();
  }, []);

  // Handle model selection
  const handleModelSelect = (model: Model3D) => {
    setSelectedModel(model);
    setUploadedModel(null);
  };

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const fileURL = URL.createObjectURL(file);
      setUploadedModel(fileURL);
      setSelectedModel(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Cube3D className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-800">3D Model Viewer</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Model List */}
            <div className="lg:col-span-1 bg-gray-50 p-4 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Available Models</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 max-h-[600px] overflow-y-auto pr-2">
                {models.map((model) => (
                  <ModelCard
                    key={model.id}
                    model={model}
                    isSelected={selectedModel?.id === model.id}
                    onClick={() => handleModelSelect(model)}
                  />
                ))}
              </div>
            </div>

            {/* 3D Viewer and Upload Feature */}
            <div className="lg:col-span-2">
              <div className="bg-white p-4 rounded-lg shadow-md">
                <h2 className="text-xl font-semibold mb-4">
                  {selectedModel ? selectedModel.name : uploadedModel ? 'Uploaded Model' : 'Select or Upload a Model'}
                </h2>
                <div className="h-[600px] w-full">
                  {selectedModel ? (
                    <ModelViewer modelUrl={selectedModel.url} isLoading={isLoading} />
                  ) : uploadedModel ? (
                    <ModelViewer modelUrl={uploadedModel} isLoading={false} />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-200 rounded-lg">
                      <p className="text-gray-600">Select a model to view</p>
                    </div>
                  )}
                </div>
                {/* Upload Button */}
                <div className="mt-4 flex flex-col items-center">
                  <label className="flex items-center space-x-2 cursor-pointer bg-blue-500 text-white px-4 py-2 rounded-lg shadow-md hover:bg-blue-600">
                    <Upload className="w-5 h-5" />
                    <span>Upload Model</span>
                    <input type="file" accept=".glb,.gltf,.obj" className="hidden" onChange={handleFileUpload} />
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white shadow-inner mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-gray-600">
            © 2025 3D Model Viewer. All models are for demonstration purposes.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;